const students = ["Elvin", "Aytac", "Murad", "Nihal"];
const days = ["17 Aprel", "18 Aprel", "19 Aprel"];

function loadData() {
  const container = document.getElementById("students");
  container.innerHTML = "";

  students.forEach((student) => {
    const div = document.createElement("div");
    div.className = "student";

    const title = document.createElement("h3");
    title.innerText = student;
    div.appendChild(title);

    days.forEach((day, i) => {
      const btn = document.createElement("span");
      btn.className = "day";
      btn.innerText = day;

      const key = `${student}-${day}`;
      const saved = localStorage.getItem(key);
      if (saved === "1") btn.classList.add("active");

      btn.onclick = () => {
        const current = btn.classList.contains("active");
        if (current) {
          localStorage.setItem(key, "0");
          btn.classList.remove("active");
        } else {
          localStorage.setItem(key, "1");
          btn.classList.add("active");
        }
      };

      div.appendChild(btn);
    });

    container.appendChild(div);
  });
}

function clearAll() {
  if (confirm("Əminsən? Bütün məlumatlar silinəcək.")) {
    localStorage.clear();
    loadData();
  }
}

window.onload = loadData;
