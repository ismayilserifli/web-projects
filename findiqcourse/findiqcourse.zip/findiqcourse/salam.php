<?php 
echo = "salam";
 ?>